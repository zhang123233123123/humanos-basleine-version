import tempfile
import unittest
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from pathlib import Path

from backend.humanos_server import Store


class ResearchEditExecutionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.store = Store(Path(self.tmp.name) / "humanos.db")
        self.profile = self.store.upsert_profile({
            "user_id": "u", "timezone": "Asia/Shanghai", "role": "student",
            "deep_work_window": "09:00-11:30",
            "research_context": {"planning_tools": ["calendar_app"], "primary_planning_tool": "calendar_app", "planning_tool_use_frequency": "daily"},
            "weekly_context": {"week_id": "2026-08-03", "weekly_available_windows": "周一至周日 08:00-21:00", "context_items": [], "keep_buffer": False},
        })
        reconciled = self.store.reconcile_weekly_setup("u", {
            "week_id": "2026-08-03", "profile": self.profile,
            "tasks": [{"title": "Analyze interviews", "due": "周日 18:00前完成", "duration": 60, "priority": "高", "expected_difficulty": 6}],
        })
        self.task = reconciled["active_ready_tasks"][0]
        self.initial = {"block_id": "block-1", "task_id": self.task["id"], "day_index": 6, "start": 9.0, "end": 10.0, "session_minutes": 60, "planned_work_minutes": 60}
        self.plan = self.store.save_proposed_plan("u", {"plan_patch": [self.initial]}, {"week_id": "2026-08-03", "request_id": "proposal-1"})

    def tearDown(self):
        self.tmp.cleanup()

    def moved(self):
        return {**self.initial, "start": 10.0, "end": 11.0}

    def confirm(self, patch, rationale_marker=False):
        payload = {"plan_id": self.plan["plan_id"], "plan_revision": self.plan["plan_revision"], "week_id": "2026-08-03", "plan_patch": patch, "unscheduled_tasks": [], "ai_task_analysis": {}, "decision": self.plan}
        if rationale_marker:
            payload["rationale"] = {"reason_codes": ["better_timing"], "generalizability": "only_this_week", "response_status": "answered", "request_id": "reason-1"}
        return self.store.confirm_plan("u", payload)

    # Planning background (1-6)
    def test_01_research_context_round_trips(self): self.assertEqual(["calendar_app"], self.store.get_profile("u")["research_context"]["planning_tools"])
    def test_02_research_context_has_self_report_source(self): self.assertEqual("user_self_report", self.store.get_profile("u")["research_context"]["source"])
    def test_03_research_context_has_capture_time(self): self.assertTrue(self.store.get_profile("u")["research_context"]["captured_at"])
    def test_04_research_context_revision_starts_at_one(self): self.assertEqual(1, self.store.get_profile("u")["research_context"]["revision"])
    def test_05_unchanged_research_context_does_not_increment(self):
        before = self.store.get_profile("u")["research_context"]["revision"]
        self.store.upsert_profile({"user_id": "u", "research_context": self.store.get_profile("u")["research_context"]})
        self.assertEqual(before, self.store.get_profile("u")["research_context"]["revision"])
    def test_06_changed_research_context_increments(self):
        self.store.upsert_profile({"user_id": "u", "research_context": {"planning_tools": ["paper_planner"], "primary_planning_tool": "paper_planner", "planning_tool_use_frequency": "weekly"}})
        self.assertEqual(2, self.store.get_profile("u")["research_context"]["revision"])

    # Edit episode and canonical diff (7-16)
    def test_07_proposal_creates_episode(self): self.assertTrue(self.plan["edit_episode_id"])
    def test_08_episode_captures_research_revision(self): self.assertEqual(1, self.store.get_edit_episode("u", self.plan["edit_episode_id"])["research_context_revision"])
    def test_09_successful_edit_event_is_effective(self):
        result = self.store.record_plan_edit_event("u", {"edit_episode_id": self.plan["edit_episode_id"], "event_type": "move_session", "before": self.initial, "after": self.moved(), "validation_result": {"valid": True}, "request_id": "event-1"})
        self.assertTrue(result["effective"])
    def test_10_failed_edit_event_is_not_effective(self):
        result = self.store.record_plan_edit_event("u", {"edit_episode_id": self.plan["edit_episode_id"], "event_type": "edit_attempt_failed", "validation_result": {"valid": False}, "request_id": "event-fail"})
        self.assertFalse(result["effective"])
    def test_11_event_request_is_idempotent(self):
        payload = {"edit_episode_id": self.plan["edit_episode_id"], "event_type": "move_session", "validation_result": {"valid": True}, "request_id": "same-event"}
        self.store.record_plan_edit_event("u", payload)
        self.assertTrue(self.store.record_plan_edit_event("u", payload)["replayed"])
    def test_12_move_is_not_misclassified_as_resize(self):
        diff = self.store.canonical_plan_diff([self.initial], [self.moved()])
        self.assertEqual((1, 0), (len(diff["moved"]), len(diff["resized"])))
    def test_13_true_resize_is_detected(self): self.assertEqual(1, len(self.store.canonical_plan_diff([self.initial], [{**self.initial, "end": 10.5, "session_minutes": 90}])["resized"]))
    def test_14_added_block_is_detected(self): self.assertEqual(1, len(self.store.canonical_plan_diff([], [self.initial])["added"]))
    def test_15_removed_block_is_detected(self): self.assertEqual(1, len(self.store.canonical_plan_diff([self.initial], [])["removed"]))
    def test_16_unchanged_plan_skips_rationale(self): self.assertFalse(self.confirm([self.initial])["requires_rationale"])

    # Rationale + execution state machine (17-24)
    def test_17_changed_plan_requires_rationale(self): self.assertTrue(self.confirm([self.moved()])["requires_rationale"])
    def test_18_rationale_confirms_changed_plan(self): self.assertEqual("confirmed", self.confirm([self.moved()], True)["plan"]["plan_status"])
    def test_19_confirmation_creates_ready_execution(self):
        self.confirm([self.initial]); self.assertEqual("up_next", self.store.current_execution("u")["mode"])
    def test_20_start_is_explicit(self):
        self.confirm([self.initial]); current = self.store.current_execution("u"); started = self.store.start_execution_session("u", {"execution_session_id": current["session"]["execution_session_id"], "request_id": "start-1"}); self.assertEqual("running", started["status"])
    def test_21_start_request_is_idempotent(self):
        self.confirm([self.initial]); current = self.store.current_execution("u"); payload = {"execution_session_id": current["session"]["execution_session_id"], "request_id": "start-same"}; self.store.start_execution_session("u", payload); self.assertEqual("running", self.store.start_execution_session("u", payload)["status"])
    def test_22_pause_preserves_session_remaining(self):
        self.confirm([self.initial]); current = self.store.current_execution("u"); run = self.store.start_execution_session("u", {"execution_session_id": current["session"]["execution_session_id"]}); base = datetime(2026, 8, 7, 9, 0, tzinfo=ZoneInfo("Asia/Shanghai"));
        with self.store.connect() as conn: conn.execute("UPDATE execution_sessions SET actual_start_at=?,resumed_at=? WHERE id=?", (base.isoformat(), base.isoformat(), run["execution_session_id"]))
        paused = self.store.pause_execution_session("u", {"execution_session_id": run["execution_session_id"], "paused_at": (base + timedelta(minutes=15)).isoformat()}); self.assertEqual(("paused", 45), (paused["status"], paused["session_remaining_minutes"]))
    def test_23_end_does_not_auto_complete_task(self):
        self.confirm([self.initial]); current = self.store.current_execution("u"); run = self.store.start_execution_session("u", {"execution_session_id": current["session"]["execution_session_id"]}); self.store.end_execution_session("u", {"execution_session_id": run["execution_session_id"], "actual_minutes": 60}); self.assertNotEqual("completed", self.store.get_task(self.task["id"], "u")["status"])
    def test_24_feedback_can_complete_task(self):
        self.confirm([self.initial]); current = self.store.current_execution("u"); run = self.store.start_execution_session("u", {"execution_session_id": current["session"]["execution_session_id"]}); self.store.end_execution_session("u", {"execution_session_id": run["execution_session_id"], "actual_minutes": 60}); self.store.save_execution_feedback("u", {"task_id": self.task["id"], "execution_session_id": run["execution_session_id"], "task_evaluation": {"completion": "completed", "actual_minutes": 60, "remaining_duration_minutes": 0}, "state_evaluation": {}, "recommendation_evaluation": {}}); self.assertEqual("completed", self.store.get_task(self.task["id"], "u")["status"])


if __name__ == "__main__":
    unittest.main()
